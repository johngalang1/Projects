package mail;
import java.io.BufferedWriter;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner; // Import the Scanner class to read text files 

public class MailSystem {
	private Message[] messages = new Message[500];
	private int messageCount;
	
	// Name: readMail 
	// Purpose: Reads the content of the file, extracts information for each message 
	//          and initializes corresponding Message objects. 
	//Details:  Handles messages with multi-line bodies
	//          connecting the lines until the "EOF" indicator is encountered. 
	//          If no file, prints an error message
	public void readMail( String file ) { 
		try {  
			this.messageCount = 0;
			File mailFile = new File( file ); 
			Scanner mail = new Scanner ( mailFile ); 
			while( mail.hasNextLine() ) 
			{ 
					messages[messageCount] = new Message();
					
					messages[messageCount].setMessageNumber( mail.nextInt() );
					messages[messageCount].setMessageStatus( mail.next().charAt(0) );
					mail.nextLine();
					messages[messageCount].setSender( mail.nextLine() );
					messages[messageCount].setRecipient( mail.nextLine() );
					messages[messageCount].setSubject( mail.nextLine() ); 
					
					String body = mail.nextLine();
					if( body.equals("EOF") )
					{ 
						messages[messageCount].setBody( "" );
						messageCount++;
					}
					else
					{ 
						String reachEOF = mail.nextLine();
						
						while( !reachEOF.equals("EOF") )
						{ 
							body += "\n" + reachEOF; 
							reachEOF = mail.nextLine();
						} 
						messages[messageCount].setBody( body );
						messageCount++;
					}
					
			} 
			mail.close();
		} 
		catch ( FileNotFoundException e) 
		{ 
			System.out.println("File does not exist.");
		}
		
	}
	// Name: findUser 
	// Purpose: Returns true if user already exists in the system
	// Details: Iterates through the messages[] array and checks if the name parameter
	//          is equivalent to the recipient, returns true if so.
	/**
	 * 
	 * @param name
	 * @return
	 */
	public Boolean findUser( String name )
	{ 
		Boolean userExists = false;
		
		for( int i = 0; i < messageCount; i++ )
		{ 
			if( messages[i].getRecipient().equals(name) )
			{ 
				userExists = true; 
				return userExists;
			}
		}
		
		return userExists;
	}
	
	// Name: findMessageAmount 
	// Purpose: Returns the number of unread messages for a user in the system.
	// Details: Iterates through the messages array to identify messages sent to the specified user.
	//          Checks the status of each identified message, and if it is 'N',
	//          increments the amount variable.
	/**
	 * 
	 * @param name
	 * @return
	 */
	public int findMessageAmount( String name )
	{ 
		int amount = 0;
		for( int i = 0; i < messageCount; i++ )
		{
			if (messages[i].getRecipient().equals(name) )
			{ 
				if(messages[i].getMessageStatus() == 'N' )
				{ 
					amount++;
				}
			}
		}
		
		return amount;
	}
	
	// Name: getMessagesForUser
	// Purpose: Returns an array of messages for a user from the messaging system
	// Details: Iterates through the messages array to determine 
	// 			the message length for the user. 
	//          Once found, creates an array with a length of messageLength
	//          and iterates through the messages to store the correct data
	/**
	 * 
	 * @param user
	 * @return
	 */
	public Message[] getMessagesForUser(String user)
	{ 
		int messageLength = 0;
		for( int k = 0; k < messageCount; k++ )
		{ 
			if (messages[k].getRecipient().equals(user) )
			{ 
				messageLength++;
			}
		}
	
		Message[] message_array = new Message[messageLength];
		int counter = 0;
		for ( int i = 0; i < messageCount; i++) 
		{ 
			
			if (messages[i].getRecipient().equals(user) ) 
			{ 
				message_array[counter] = new Message();
				
				message_array[counter].setSender(messages[i].getSender()); 
				message_array[counter].setMessageNumber(messages[i].getMessageNumber()); 
				message_array[counter].setMessageStatus(messages[i].getMessageStatus());
				message_array[counter].setSubject(messages[i].getSubject()); 
				
				counter++;
			}
		}
		
		return message_array;
	}
	
	//Name: retrieveNumber
	//Purpose: Checks if a message number exists within the system
	//Details: Checks if the message's recipient and number match.
	//         If a match is found, returns true and breaks out of the loop
	/**
	 * 
	 * @param number
	 * @param user
	 * @return
	 */
	public Boolean retrieveNumber(int number, String user ) 
	{
		Boolean numberExists = false;
		for( int i = 0; i < messageCount; i++ )
		{ 
			if( messages[i].getRecipient().equals(user) && 
				messages[i].getMessageNumber() == number )
			{ 
				numberExists = true;
				break;
			} 
		}
		
		return numberExists;
	}
	// Name: printMessage
	// Purpose: Print a message specified by its number and user.
	// Details: Iterates through the messages in the system.
	//          Checks if the message is new. If yes, marks it as read ('R') and prints "(New)" in the output.
	//          Prints the message number, sender, subject, and body.
	/**
	 * 
	 * @param number
	 * @param user
	 * @param out
	 */
	public void printMessage(int number, String user, PrintStream out)
	{
		for( int i = 0; i < messageCount; i++ )
		{ 
			if( messages[i].getRecipient().equals(user) && 
				messages[i].getMessageNumber() == number )
			{ 
				if( messages[i].getMessageStatus() == 'N' )
				{ 
					out.println( "Message # " + number + " (New)");
					messages[i].setMessageStatus('R');
				} 
				else 
				{ 
					out.println( "Message # " + number );
				} 
				
				out.println( "From: " + messages[i].getSender() );
				out.println( "Subject: " + messages[i].getSubject() ); 
				out.println( "‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐" ); 
				out.println( messages[i].getBody() ); 
				out.println( "‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐" ); 
			} 
		}
	}

	// Name: addMessage 
	// Purpose: To add a message to the mail system 
	// Details: Takes parameters for a message and creates a new Message object. 
	//          This new message is then added to the array of messages in the MailSystem
	/**
	 * 
	 * @param user
	 * @param recipient
	 * @param subject
	 * @param body
	 */
	public void addMessage(String user, String recipient, String subject, String body) 
	{
		
		messages[messageCount] = new Message();
		messages[messageCount].setMessageNumber(messageCount + 1);
		messages[messageCount].setMessageStatus('N');
		messages[messageCount].setSender(user);
		messages[messageCount].setRecipient(recipient);
		messages[messageCount].setSubject(subject);
		messages[messageCount].setBody(body);
		
		messageCount++;
		
	}

	// Name: writeMail 
	// Purpose: To update the mail text file by overwriting and rewriting information
	// Details: Uses BufferedWriter and FileWriter to write data into the file
	/**
	 * 
	 * @param file
	 */
	public void writeMail( String file ) 
	{ 
			try 
			{
				BufferedWriter mailwriter = new BufferedWriter( new FileWriter( file ));
				
				for( int i = 0; i < messageCount; i++)
				{ 
					mailwriter.write(messages[i].getMessageNumber() + " "
							+ messages[i].getMessageStatus() + "\n" 
							+ messages[i].getSender() + "\n" 
							+ messages[i].getRecipient() + "\n" 
							+ messages[i].getSubject() + "\n" 
							+ messages[i].getBody() + "\nEOF\n" );
				}
				
				mailwriter.close();
			} catch (IOException e) 
			{
				e.printStackTrace();
			}

	}

}
