package mail;
import java.io.PrintStream;

public class Message {

	private int MessageNumber; 
	private char MessageStatus; 
	private String Sender; 
	private String Recipient; 
	private String Subject; 
	private String Body;  
	 
	//Setters
	public void setMessageNumber( int number )
	{ 
		this.MessageNumber = number;
	} 
	
	public void setMessageStatus( char status )
	{ 
		this.MessageStatus = status;
	} 
	
	public void setSender( String sender )
	{ 
		this.Sender = sender;
	} 
	
	public void setRecipient( String recipient )
	{ 
		this.Recipient = recipient;
	} 
	
	public void setSubject( String subject )
	{ 
		this.Subject = subject;
	} 
	
	public void setBody( String body )
	{ 
		this.Body = body;
	}
	
	//Getters
	public int getMessageNumber()
	{ 
		return MessageNumber;
	} 
	
	public char getMessageStatus()
	{ 
		return MessageStatus;
	} 
	
	public String getSender()
	{ 
		return Sender;
	} 
	
	public String getRecipient()
	{ 
		return Recipient;
	} 
	
	public String getSubject()
	{ 
		return Subject;
	} 
	
	public String getBody()
	{ 
		return Body;
	}

	//Name: printAsLine 
	//Purpose: This function prints the message details in a formatted line to the specified PrintStream. 
	//Details: Formats the message number, status, sender, and subject according 
	// to the amount of characters specified and handles truncation of sender and subject to fit into the column widths. 
	// If the message status equals 'R', replace it with a space character.
	/**
	 * 
	 * @param out
	 */
	public void printAsLine(PrintStream out) {
		
		String printNumber = String.format("%3d", MessageNumber ); 
		char printStatus = MessageStatus; 
		String printSender = String.format("%-15s", Sender ); 
		String printSubject = String.format("%-30s", Subject );   
		
		if (printStatus == 'R')
		{ 
			printStatus = ' ';
		}
		
		if( !(printSender.length() <= 15) )
		{ 
			printSender = printSender.substring( 0, 15 );
		} 
		
		if( !(printSubject.length() <= 30) )
		{ 
			printSubject = printSubject.substring( 0, 30 );
		}
		
		out.println( printNumber + " " + printStatus + " "
				   + printSender + " " + printSubject );
	}
	
}
